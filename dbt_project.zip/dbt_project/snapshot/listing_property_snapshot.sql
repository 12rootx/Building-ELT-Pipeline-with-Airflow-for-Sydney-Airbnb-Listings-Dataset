{% snapshot listing_property_snapshot %}

{{
        config(
          strategy='timestamp',
          unique_key='listing_record_id',
          updated_at='scraped_date',
          alias='snap_listing_property'
        )
    }}


select 
    {{ dbt_utils.generate_surrogate_key(['listing_id', 'month']) }} as listing_record_id,
    *
 from {{ ref('s_listing_property') }}


{% endsnapshot %}