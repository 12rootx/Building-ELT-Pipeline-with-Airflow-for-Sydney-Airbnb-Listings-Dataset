{% snapshot host_snapshot %}

{{
        config(
          strategy='timestamp',
          unique_key='host_record_id',
          updated_at='scraped_date',
          alias='snap_host'
        )
    }}


select 
    {{ dbt_utils.generate_surrogate_key(['host_id', 'month']) }} as host_record_id,
    *
from {{ ref('s_host') }}


{% endsnapshot %}