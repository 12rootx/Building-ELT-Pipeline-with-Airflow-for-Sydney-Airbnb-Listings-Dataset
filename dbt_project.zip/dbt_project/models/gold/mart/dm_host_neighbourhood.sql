{{
    config(
        alias='host_neighbourhood'
    )
}}

with active as (

    select 
        *,
        (30 - availability_30) * price as estimated_revenue
     from {{ ref('g_facts') }}
    where has_availability=1

)

select
    coalesce(c.lga_name, 'UNKNOWN') as host_neighbourhood_lga,
    date_trunc('month', a.scraped_date)::date as month,
    count(distinct a.host_id) as host_cnt,
    sum(a1.estimated_revenue) total_estimated_revenue,
    sum(a1.estimated_revenue) / count(distinct a.host_id) as estimated_revenue_per_host
from {{ ref('g_facts') }} a
left join {{ ref('g_dim_host') }} b 
    on a.host_id = b.host_id 
    and a.scraped_date::timestamp >= b.valid_from 
    and a.scraped_date::timestamp < coalesce(b.valid_to, '9999-12-31'::timestamp)
left join {{ ref('g_dim_suburb') }} c 
    on b.suburb_id = c.suburb_id 
left join active a1 
    on a.listing_record_id = a1.listing_record_id
group by 1,2
order by 1,2