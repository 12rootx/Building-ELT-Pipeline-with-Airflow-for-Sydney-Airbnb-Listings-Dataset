{{
    config(
        alias='property_type'
    )
}}


with total as (

    select 
    b.property_type,
    b.room_type,
    b.accommodates,
    date_trunc('month', a.scraped_date)::date as month,
    count(distinct a.listing_id) as total_listing,
	count(distinct case when a.has_availability=1 then a.listing_id end) as act_listing,
	count(distinct a.listing_id) - count(distinct case when a.has_availability=1 then a.listing_id end) as ina_listing,
    count(distinct a.host_id) as total_host,
    count(distinct (case when c.host_is_superhost=1 then a.host_id end)) as sup_host
    from {{ ref('g_facts') }} a
    left join {{ ref('g_dim_listing_property') }} b on a.listing_id = b.listing_id and a.scraped_date::timestamp >= b.valid_from and a.scraped_date::timestamp < coalesce(b.valid_to, '9999-12-31'::timestamp)
    left join {{ ref('g_dim_host') }} c on a.host_id = c.host_id and a.scraped_date::timestamp >= c.valid_from and a.scraped_date::timestamp < coalesce(c.valid_to, '9999-12-31'::timestamp)
    group by 1, 2, 3, 4

),

active as (

    select 
    b.property_type,
    b.room_type,
    b.accommodates,
    date_trunc('month', a.scraped_date)::date as month,
    count(*) as active_listing,
    min(a.price) as min_act_price,
    max(a.price) as max_act_price,
    percentile_cont(0.5) within group (order by a.price) AS med_act_price,
    avg(a.price) as avg_act_price,
    avg(a.review_scores_rating) as avg_act_rating,
    sum(30 - availability_30) as num_stays,
    sum((30 - availability_30) * price) as estimated_revenue
    from {{ ref('g_facts') }} a
    left join {{ ref('g_dim_listing_property') }} b on a.listing_id = b.listing_id and a.scraped_date::timestamp >= b.valid_from and a.scraped_date::timestamp < coalesce(b.valid_to, '9999-12-31'::timestamp)
    where has_availability=1
    group by 1, 2, 3, 4

),

pre_month as (

    select 
        b.property_type,
        b.room_type,
        b.accommodates,
        (date_trunc('month', a.scraped_date) + interval '1 month')::date AS month,
	count(distinct case when a.has_availability=1 then a.listing_id end) as pre_act_listing,
	count(distinct a.listing_id) - count(distinct case when a.has_availability=1 then a.listing_id end) as pre_ina_listing
    from {{ ref('g_facts') }} a
    left join {{ ref('g_dim_listing_property') }} b on a.listing_id = b.listing_id and a.scraped_date::timestamp >= b.valid_from and a.scraped_date::timestamp < coalesce(b.valid_to, '9999-12-31'::timestamp)
    group by 1, 2, 3, 4

)

select
    a0.property_type,
    a0.room_type,
    a0.accommodates,
    a0.month,
    (100.00 * a0.act_listing / nullif(a0.total_listing,0)) as act_listing_rate,
    a1.min_act_price,
    max_act_price,
    med_act_price,
    avg_act_price,
    a0.total_host,
    (100.00 * a0.sup_host / nullif(a0.total_host,0)) as sup_host_rate,
	(100.00 * (a0.act_listing - a2.pre_act_listing) / nullif(a2.pre_act_listing,0)) as percent_change_act,
	(100.00 * (a0.ina_listing - a2.pre_ina_listing) / nullif(a2.pre_ina_listing,0)) as percent_change_ina,
    num_stays,
    estimated_revenue / nullif(a0.act_listing,0) as estimated_revenue_per_listing
from total a0
left join active a1 using (property_type, room_type, accommodates, month)
left join pre_month a2 using (property_type, room_type, accommodates, month)
order by 1,2,3,4