{{
    config(
        unique_key='lga_code',
        alias='census_g01'
    )
}}

select * from {{ ref('s_census_g01') }}