{{
    config(
        unique_key='lga_code',
        alias='census_g02'
    )
}}

select * from {{ ref('s_census_g02') }}