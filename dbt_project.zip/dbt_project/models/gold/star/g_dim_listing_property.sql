{{
    config(
        unique_key='listing_record_id',
        alias='dim_listing_property'
    )
}}

with

source  as (

    select * from {{ ref('listing_property_snapshot') }}

),

cleaned as (
    select
    listing_record_id,
    listing_id,
    month,
    property_type,
    room_type,
    accommodates,
        case 
          when dbt_valid_from = (select min(dbt_valid_from) from source) then '1900-01-01'::timestamp 
          else dbt_valid_from 
          end as valid_from,
        dbt_valid_to as valid_to
    from source
)

select * from cleaned