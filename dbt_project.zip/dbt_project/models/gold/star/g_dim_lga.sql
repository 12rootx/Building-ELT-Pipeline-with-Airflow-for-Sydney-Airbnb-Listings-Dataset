{{
    config(
        unique_key='lga_code',
        alias='dim_lga'
    )
}}

with

source  as (

    select * from {{ ref('s_lga') }}

)
select * from source