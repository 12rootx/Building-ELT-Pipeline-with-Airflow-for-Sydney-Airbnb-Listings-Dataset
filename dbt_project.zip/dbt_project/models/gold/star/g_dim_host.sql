{{
    config(
        unique_key='host_record_id',
        alias='dim_host'
    )
}}

with

source  as (

    select * from {{ ref('host_snapshot') }}

),

cleaned as (
    select
        host_record_id,
        host_id,
        host_name,
        month,
        host_since,
        host_is_superhost,
        suburb_id,
        case 
          when dbt_valid_from = (select min(dbt_valid_from) from source) then '1900-01-01'::timestamp 
          else dbt_valid_from 
          end as valid_from,
        dbt_valid_to as valid_to
    from source
)

select * from cleaned