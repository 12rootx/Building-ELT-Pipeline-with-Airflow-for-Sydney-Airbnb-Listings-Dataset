{{
    config(
        unique_key='suburb_id',
        alias='dim_suburb'
    )
}}

with

source  as (

    select * from {{ ref('s_suburb') }}

)

select * from source