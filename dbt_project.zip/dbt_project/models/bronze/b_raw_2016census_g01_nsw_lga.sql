{{
    config(
        alias='b_census_g01'
    )
}}

select * from {{ source('raw', 'raw_2016census_g01_nsw_lga') }}