{{
    config(
        alias='b_lga_code'
    )
}}

select * from {{ source('raw', 'raw_nsw_lga_code') }}