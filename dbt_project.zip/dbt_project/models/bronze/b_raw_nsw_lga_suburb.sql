{{
    config(
        alias='b_lga_suburb'
    )
}}

select * from {{ source('raw', 'raw_nsw_lga_suburb') }}