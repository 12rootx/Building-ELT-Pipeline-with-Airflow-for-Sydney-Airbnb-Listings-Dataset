{{
    config(
        alias='b_census_g02'
    )
}}

select * from {{ source('raw', 'raw_2016census_g02_nsw_lga') }}