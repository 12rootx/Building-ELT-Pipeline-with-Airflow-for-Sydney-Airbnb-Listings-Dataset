{{
    config(
        alias='b_listings'
    )
}}

select 
    * 
from {{ source('raw', 'raw_listings') }}