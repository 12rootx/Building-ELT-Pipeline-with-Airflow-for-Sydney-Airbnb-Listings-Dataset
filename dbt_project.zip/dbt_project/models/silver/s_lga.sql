{{
    config(
        unique_key='lga_code',
        alias='s_lga_code'
    )
}}

with

transformed_lga  as (

select 
    lga_code::int,
    lga_name,
    current_timestamp::timestamp AS script_date
from {{ ref('b_raw_nsw_lga_code') }}

)

select * from transformed_lga