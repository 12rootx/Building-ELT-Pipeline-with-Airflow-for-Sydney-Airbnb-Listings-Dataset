{{
    config(
        unique_key='host_id',
        alias='s_host'
    )
}}

with hosts as (
    select
        s1.host_id::int,
        s1.host_name,
        to_date(s1.scraped_date, 'YYYY-MM-DD') as scraped_date,
        date_trunc('month', to_date(scraped_date,'YYYY-MM-DD')) as month,
        to_date(translate(lower(s1.host_since), 'abcdefghijklmnopqrstuvwxyz', ''), 'DD/MM/YYYY') AS host_since,
        case when s1.host_is_superhost = 't' then 1 
             when s1.host_is_superhost = 'f' then 0 
             else -1 
        end AS host_is_superhost,
        s2.suburb_id,
        row_number() over(partition by host_id, date_trunc('month', to_date(scraped_date,'YYYY-MM-DD')) order by scraped_date desc) rn
    from 
        {{ ref('b_raw_listings') }} as s1
    left join  
        {{ ref('s_suburb') }} as s2 on trim(lower(s1.host_neighbourhood)) = trim(lower(s2.suburb_name))
)

select 
    host_id,
    host_name,
    scraped_date,
    month,
    host_since,
    host_is_superhost,
    suburb_id
from hosts
where rn=1