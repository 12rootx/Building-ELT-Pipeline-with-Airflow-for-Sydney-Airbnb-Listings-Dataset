{{
    config(
        unique_key='suburb_id',
        alias='s_suburb'
    )
}}

with

transformed_suburb  as (

select
    {{ dbt_utils.generate_surrogate_key(['suburb_name', 'lga_name']) }} as suburb_id,
    suburb_name,
    lga_name,
    current_timestamp::timestamp AS script_date
from 
    {{ ref('b_raw_nsw_lga_suburb') }}

)

select * from transformed_suburb