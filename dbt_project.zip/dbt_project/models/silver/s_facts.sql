{{
    config(
        unique_key='listing_id',
        alias='s_facts'
    )
}}

with

transformed as (
select
    listing_id::int,
    scrape_id::bigint,
    to_date(scraped_date, 'YYYY-MM-DD')::date as scraped_date,
    date_trunc('month', to_date(scraped_date,'YYYY-MM-DD')) as month,
    host_id::int,
    l.lga_code,    
    price::float,
    case when has_availability='t' then 1 
        when has_availability='f' then 0 
        else -1 
        end AS has_availability,
    availability_30::int,
    number_of_reviews::int,
    NULLIF(review_scores_rating::float, 'NaN') as review_scores_rating,
    NULLIF(review_scores_accuracy::float, 'NaN') as review_scores_accuracy,
    NULLIF(review_scores_cleanliness::float, 'NaN') as review_scores_cleanliness,
    NULLIF(review_scores_checkin::float, 'NaN') as review_scores_checkin,
    NULLIF(review_scores_communication::float, 'NaN') as review_scores_communication,
    NULLIF(review_scores_value::float, 'NaN') as review_scores_value
from 
    {{ ref('b_raw_listings') }} AS s
left join 
    {{ ref('s_lga') }} AS l on s.listing_neighbourhood = l.lga_name
)

select * from transformed
