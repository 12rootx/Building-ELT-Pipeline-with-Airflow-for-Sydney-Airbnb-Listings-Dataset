{{
    config(
        unique_key='lga_code',
        alias='s_census_g02'
    )
}}

with

transformed_g02 as (
    select replace(lga_code_2016,'LGA', '')::int as lga_code,
	Median_age_persons::int,
	Median_mortgage_repay_monthly::int,	
	Median_tot_prsnl_inc_weekly::int,	
	Median_rent_weekly::int,		
	Median_tot_fam_inc_weekly::int,		
	Average_num_psns_per_bedroom::float,	
	Median_tot_hhd_inc_weekly::int,		
	Average_household_size::float
    from {{ ref('b_raw_2016census_g02_nsw_lga') }}
)

select * from transformed_g02