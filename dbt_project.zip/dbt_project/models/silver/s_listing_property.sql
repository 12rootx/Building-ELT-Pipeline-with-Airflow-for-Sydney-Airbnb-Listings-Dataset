{{
    config(
        unique_key='listing_id',
        alias='s_listing_property'
    )
}}

with

transformed as (

select
    listing_id::int,
    to_date(scraped_date, 'YYYY-MM-DD') as scraped_date,
    date_trunc('month', to_date(scraped_date,'YYYY-MM-DD')) as month,
    l2.lga_code,
    property_type,
    room_type,
    accommodates::int
from 
    {{ ref('b_raw_listings') }} l1
left join  
    {{ ref('s_lga') }} AS l2 on lower(l1.listing_neighbourhood) = lower(l2.lga_name)
)

select * from transformed
